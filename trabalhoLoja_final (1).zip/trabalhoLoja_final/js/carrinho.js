window.onload = async function carrega_carrinho() {
    var resultado = await fetch("../php/carrinho_retrieve.php", {
        method:"GET"
    });

    var carrinho = await resultado.json();

    for(var i = 0; i < carrinho.length; i++){

        var conteudo2 = 
        `
        <div class="container">
            <div class="flip">
                <div class="frente">
                    <div class="nome">${carrinho[i].nome}</div>
                    <div class="card-img"><img class="img" src="../img/${carrinho[i].id}.png" alt="" width="100px"></div>
                    <div class="preço">R$${carrinho[i].preco}.00</div>
                    <div class="carrinho-remover" onclick="remover(${carrinho[i].id_compra});window.location.reload();"><i class="fa-solid fa-minus"></i></div>
                </div>
                <div class="tras">
                </div>
            </div>
        </div>
        `

        document.getElementById('card-carrinho').innerHTML += conteudo2;
    };

    var usuario = await fetch("../php/usuario.php", {
        method: "GET"
    });

    var usuario_dados = await usuario.json();
    document.getElementById('usuario').innerHTML = `${usuario_dados[0]}`;
}

function remover(id){
    var remover_compra = new FormData();
    remover_compra.append("id", id);

    fetch("../php/remover.php", {
        method: "POST",
        body: remover_compra
    });
}