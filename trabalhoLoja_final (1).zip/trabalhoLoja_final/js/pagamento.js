

window.onload = async function carrega(){
    var usuario = await fetch("../php/usuario.php", {
        method: "GET"
    });

    var usuario_dados = await usuario.json();
    if (usuario_dados && usuario_dados.length > 0){
        usuarioAutenticado = true;
        document.getElementById('usuario').innerHTML = `${usuario_dados[0]}`;

        if (usuario_dados[2] == 1){  // se for admin
            document.getElementById('usuario').innerHTML = `ADMIN`;
        };

        revisar();
    } else {
        var sair = document.getElementById('sair'); sair.remove();
    };
}


async function revisar(){

    var resultado = await fetch("../php/carrinho_retrieve.php", {
        method: "GET"
    });

    var carrinho = await resultado.json();
    var soma = 0;

    document.getElementById('carregar').innerHTML = '';
    document.getElementById('revisar-pagamento').style.backgroundColor = '#04AA6D';

    var cardCarrinhoDiv = document.createElement('div');
    cardCarrinhoDiv.id = 'card-carrinho';

    var totalCompraDiv = document.createElement('div');
    totalCompraDiv.id = 'total-compra';

    var conteudo2 = ``;
    for (var i = 0; i < carrinho.length; i++) {
        conteudo2 +=
            `
        <div class="produto">
            <div class="card-nome">${carrinho[i].nome}</div>
            <div class="card-imagem"><img class="img" src="../img/${carrinho[i].id}.png" alt="" width="100px"></div>
            <div class="card-preco">R$${carrinho[i].preco}.00</div>
        </div>
        `;
        soma = soma + parseInt(carrinho[i].preco);
    }

    cardCarrinhoDiv.innerHTML = conteudo2;
    totalCompraDiv.innerHTML = 'Valor total da compra: R$' + soma + '.00';

    var carregarDiv = document.getElementById('carregar');
    carregarDiv.append(totalCompraDiv);
    carregarDiv.append(cardCarrinhoDiv);

    document.getElementById('carregar').innerHTML += `<div id="proximo-revisar" class="proximo" onclick="tipo()">Próximo</div>`;
    
}

async function tipo(){

    var conteudo2 =
    `
    <div class="form-pagamento">
        <h1>Selecione uma forma de pagamento:</h1>

        <div class="opcao-pagamento">
            <input type="radio" id="cartao-credito" name="pagamento" value="credito">
            Cartão de crédito
            <label for="cartao-credito">
                <img src="../img/cartao_credito.png" width="30px">
            </label>
        </div>

        <div class="opcao-pagamento">
            <input type="radio" id="cartao-debito" name="pagamento" value="debito">
            Cartão de débito
            <label for="cartao-debito">
                <img src="../img/cartao_debito.png" width="30px">
            </label>
        </div>

        <div class="opcao-pagamento">
            <input type="radio" id="pix" name="pagamento" value="pix">
            PIX
            <label for="pix">
                <img src="../img/pix.png" width="60px">
            </label>
        </div>

        <div id="proximo-tipo" class="proximo">Próximo</div>
    </div>

    `;
    document.getElementById('carregar').innerHTML = '';
    document.getElementById('carregar').innerHTML = conteudo2;
    document.getElementById('revisar-pagamento').style.backgroundColor = '#231f20';
    document.getElementById('tipo-pagamento').style.backgroundColor = '#04AA6D';

    document.querySelector('.proximo').addEventListener('click',
    function() {
        var metodo = document.querySelector('input[name="pagamento"]:checked').value;
        detalhes(metodo);
    });
}

async function detalhes(tipo){
    
    if (tipo == 'debito')
    {
        var conteudo2 =
        `
        <div class="form-detalhes">
            <h1>Detalhes do Pagamento com Cartão de Débito</h1>
            <label for="numero-cartao">Número do Cartão:</label>
            <input type="number" id="numero-cartao" name="numero-cartao" placeholder="**** **** **** ****" maxlength="16" required><br>

            <label for="validade-cartao">Validade:</label>
            <input type="date" id="validade-cartao" name="validade-cartao" required><br>

            <label for="cvv-cartao">CVV:</label>
            <input type="number" maxlength="3" id="cvv-cartao" name="cvv-cartao" placeholder="***" required><br>
            
            <div id="proximo-detalhes" onclick="finalizar('${tipo}')">Finalizar Pagamento</div>
        </div>
    `;
    } else if (tipo == 'credito'){

        var conteudo2 =
        `
        <div class="form-detalhes">
            <h1>Detalhes do Pagamento com Cartão de Crédito</h1>
            <label for="numero-cartao">Número do Cartão:</label>
            <input type="number" id="numero-cartao" name="numero-cartao" placeholder="**** **** **** ****" maxlength="16" required><br>

            <label for="validade-cartao">Validade:</label>
            <input type="date" id="validade-cartao" name="validade-cartao" required><br>

            <label for="cvv-cartao">CVV:</label>
            <input type="number" maxlength="3" id="cvv-cartao" name="cvv-cartao" placeholder="***" required><br>
            
            <div id="proximo-detalhes" onclick="finalizar('${tipo}')">Finalizar Pagamento</div>
        </div>
    `;

    } else if (tipo == 'pix'){

        var conteudo2 = 
        `
        <div class="form-detalhes">
            <h1>Detalhes do Pagamento com PIX</h1>
            <div class="form-img">
                <img id="form-img" src='../img/qrcode.png' width="100px"><br>
            </div>
            <div id="proximo-detalhes" onclick="finalizar('${tipo}')">Finalizar Pagamento</div>
        </div>
    `;

    };

    document.getElementById('carregar').innerHTML = '';
    document.getElementById('carregar').innerHTML = conteudo2;
    document.getElementById('tipo-pagamento').style.backgroundColor = '#231f20';
    document.getElementById('detalhes-pagamento').style.backgroundColor = '#04AA6D';

}

async function finalizar(tipo){

    var resultado = await fetch("../php/carrinho_retrieve.php", {
        method: "GET"
    });

    var carrinho = await resultado.json();
    
    var compra = carrinho.length;
    dados = new FormData();
    dados.append('compras', compra);

    await fetch('../php/compras.php', {
        method: 'POST',
        body: dados
    });

    var conteudo2 =
    `
    <div class="finalizar-tudo">
        <img src="../img/sucesso.png" width: 500px>
        <div class="finalizar" onclick="window.location.href = '../html/index.html' ">Ok, entendi</div>
    </div>

    `;

    document.getElementById('carregar').innerHTML = '';
    document.getElementById('carregar').innerHTML = conteudo2;
    document.getElementById('detalhes-pagamento').style.backgroundColor = '#231f20';
    document.getElementById('finalizar-compra').style.backgroundColor = '#04AA6D';

}
