async function cadastrar(){
    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var senha = document.getElementById('senha').value;
    var confirmar_senha = document.getElementById('confirmar-senha').value;

    if (senha != confirmar_senha || senha === null || confirmar_senha === null){
        console.log("Erro na digitação: senhas incompatíveis!");
        alert("Erro na digitação: senhas incompatíveis!");
    }else{
        var hash = CryptoJS.SHA256(senha).toString(CryptoJS.enc.Hex);

        var dados = new FormData();
        dados.append('nome', nome); dados.append('email', email); dados.append('senha', hash);

        await fetch('../php/cadastrar.php', {
            method: 'POST',
            body: dados
        })

        window.location.href = '../html/autenticar.html';
    }
}

async function autenticar(){
    var email = document.getElementById('email').value;
    var senha = document.getElementById('senha').value;

    var conteudo = await fetch('../php/autenticar.php', {
        method: 'GET'
    })

    var hash = CryptoJS.SHA256(senha).toString(CryptoJS.enc.Hex);

    var dados = await conteudo.json()
    var userFound = false;

    for (var i = 0; i < dados.length; i++) {
        if (dados[i].email === email && dados[i].hash === hash) {
            userFound = true;
            console.log("Usuário autenticado!");
            var form_dados = new FormData();
            form_dados.append('email', email); form_dados.append('senha', hash)
            await fetch('../php/session.php', {
                method: 'POST',
                body: form_dados
            });
            window.location.href = '../html/index.html';
            break;
        }
    }

    if (!userFound) {
        console.log("ERRO: E-mail ou senha inválidos!");
        alert("ERRO: E-mail ou senha inválidos!");
    }
}