window.onload = async function carrega() {
    var usuario = await fetch("../php/usuario.php", {
        method: "GET"
    });

    var usuario_dados = await usuario.json();
    if (usuario_dados && usuario_dados.length > 0){
        document.getElementById('usuario').innerHTML = `${usuario_dados[0]}`;

        if (usuario_dados[2] == 1){  // se for admin
            document.getElementById('usuario').innerHTML = `ADMIN`;
            document.getElementById('admin-page').innerHTML = `
            <i onclick="window.location.href = 'adm.html'" class="fa-solid fa-gear"></i>
            `;
        };
    } else {
        var sair = document.getElementById('sair'); sair.remove();
    };

    var resultado = await fetch("../php/retrieve.php", {
        method:"GET"
    });

    var dados = await resultado.json();

    for(var i = 0; i < dados.length; i++){

        var conteudo = 
        `
        <div class="container">
            <div class="flip">
                <div class="frente">
                    <div class="nome">${dados[i].nome}</div>
                    <div class="card-img"><img class="img" src="../img/${dados[i].id}.png" alt="" width="100px"></div>
                    <div class="preço">R$${dados[i].preco}.00</div>
                    <div class="carrinho" onclick="carrinho(${dados[i].id}, ${usuario_dados[1]})"><i class="fa-solid fa-shopping-cart"></i></div>
                </div>
                <div class="tras">
                </div>
            </div>
        </div>
        `;
        document.getElementById('frenteLoja').innerHTML += conteudo;
    };

    var pesquisa = document.getElementById('pesquisa');
    pesquisa.addEventListener('input', function() {
        var termo = pesquisa.value.toLowerCase();

        var filtro = dados.filter(function(produto) {
            return produto.nome.toLowerCase().includes(termo);
        });

        document.getElementById('frenteLoja').innerHTML = '';

        for (var i = 0; i < filtro.length; i++) {
            var conteudo = `
        <div class="container">
            <div class="flip">
                <div class="frente">
                    <div class="nome">${filtro[i].nome}</div>
                    <div class="card-img"><img class="img" src="../img/${filtro[i].id}.png" alt="" width="100px"></div>
                    <div class="preço">R$${filtro[i].preco}.00</div>
                    <div class="carrinho" onclick="carrinho(${filtro[i].id}, ${usuario_dados[1]})"><i class="fa-solid fa-shopping-cart"></i></div>
                </div>
                <div class="tras">
                </div>
            </div>
        </div>
            `;
            document.getElementById('frenteLoja').innerHTML += conteudo;
        }
    });


}

function carrinho(id_produto, id_usuario){
    
    var compras = new FormData();
    compras.append("id_produto", id_produto); compras.append("id_usuario", id_usuario)

    fetch("../php/carrinho.php", {
        method: "POST",
        body: compras
    });
}

async function sair(){
    await fetch("../php/sair.php", {
        method: 'GET'
    });
}

    