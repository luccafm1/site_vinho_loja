window.onload = async function(){
    var conteudo = await fetch('../php/retrieve.php', {
        method: 'GET'
    });

    var produtos = await conteudo.json();
    
    for (var i = 0; i < produtos.length; i++){
        var produto = `
        <option value="${produtos[i].nome}">${produtos[i].nome}</option>
        `;
        document.getElementById('produtos').innerHTML += produto;
    };
}

async function gravar() {

    var nome = document.getElementById("nome").value;
    var preco = document.getElementById("preco").value;
    var arquivo = document.getElementById("arquivo").files;

    console.log(arquivo);

    var dados = new FormData();
    dados.append('nome', nome); dados.append('preco', preco); dados.append('arquivo', arquivo[0]);
    
    var conteudo = await fetch('../php/gravar.php', {
        method: 'POST',
        body: dados
    });

    alert(`Produto ${nome} gravado com sucesso!`);
}

async function deletar(){
    
    var selecionado = document.getElementById('produtos').value;
    var dados = new FormData();
    dados.append('selecionado', selecionado);

    var conteudo2 = await fetch('../php/deletar.php', {
        method: 'POST',
        body: dados
    });

}