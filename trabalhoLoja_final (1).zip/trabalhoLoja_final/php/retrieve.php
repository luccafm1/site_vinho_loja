<?php
    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $result = mysqli_query($conexao, "SELECT * FROM produtos");

    $produtos = array();

    while ($row = mysqli_fetch_assoc($result)) {
        array_push($produtos, $row);
    };

    $json = json_encode($produtos);

    echo $json;

?>
