<?php

    $id = $_POST['id'];

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $result = mysqli_query($conexao, "SELECT * FROM carrinho");

    $query = "DELETE FROM carrinho WHERE id_compra='$id'";

    mysqli_query($conexao, $query);

?>