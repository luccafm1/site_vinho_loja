<?php

    $email = $_POST['email'];

    session_start();
    
    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $query = mysqli_query($conexao, "
    SELECT nome, id, adm FROM usuario 
    WHERE '$email' = email
    ");

    $usuario = mysqli_fetch_assoc($query);

    $_SESSION['email'] = $email;
    $_SESSION['nome'] = $usuario['nome'];
    $_SESSION['id'] = $usuario['id'];
    $_SESSION['adm'] = $usuario['adm'];

?>