<?php

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");
    $query = "SELECT * FROM usuario";
    $resultado = mysqli_query($conexao, $query);

    $usuarios = array();

    while ($ler = mysqli_fetch_assoc($resultado)){
        array_push($usuarios, $ler);
    };

    $json = json_encode($usuarios);

    echo $json;

?>