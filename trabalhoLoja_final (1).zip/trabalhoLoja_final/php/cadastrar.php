<?php

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $hash = $_POST['senha'];

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");
    $query = "INSERT INTO usuario (nome, email, hash, adm) VALUES ('$nome', '$email', '$hash', 0)";
    mysqli_query($conexao, $query);

?>