<?php
$nome = $_POST['nome'];
$preco = $_POST['preco'];
$arquivo = $_FILES['arquivo'];

$conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

if ($arquivo['type'] == 'image/png' || $arquivo['type'] == 'image/jpeg') {

    $query = "INSERT INTO produtos (nome, preco) VALUES ('$nome', '$preco')";

    mysqli_query($conexao, $query);

    $id = mysqli_insert_id($conexao);

    move_uploaded_file($arquivo['tmp_name'], '../img/'.$id.'.png' );

} else {
    echo 'Erro: Arquivo precisa ser imagem (tipo png ou jpg)';
}
?>
