<?php

    $id_produto = $_POST['id_produto'];
    $id_usuario = $_POST['id_usuario'];

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $query = "INSERT INTO carrinho (id_produto, id_usuario) VALUES ('$id_produto', '$id_usuario')";

    mysqli_query($conexao, $query);

    
?>