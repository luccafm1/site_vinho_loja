<?php

    session_start();

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $compras = $_POST['compras'];
    $id = $_SESSION['id'];

    $query = "SELECT compras FROM usuario WHERE id = '$id'";
    $result = mysqli_query($conexao, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $compras_atual = $row['compras'];

        $novo_total_compras = $compras_atual + $compras;

        $update_query = "UPDATE usuario SET compras = '$novo_total_compras' WHERE id = '$id'";
        mysqli_query($conexao, $update_query);
    }

    $query_carrinho = "DELETE FROM carrinho WHERE id_usuario = '$id'";
    mysqli_query($conexao, $query_carrinho);

?>