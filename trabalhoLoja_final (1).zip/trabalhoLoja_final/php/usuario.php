<?php
    session_start();

    if(isset($_SESSION['email']) && isset($_SESSION['nome']) && isset($_SESSION['id']) && isset($_SESSION['adm'])) {
        $resposta = array($_SESSION['nome']);
        array_push($resposta, $_SESSION['id']);
        array_push($resposta, $_SESSION['adm']);
        
        $json = json_encode($resposta);
        echo $json;
    } else {
        echo json_encode('');
    }

?>

