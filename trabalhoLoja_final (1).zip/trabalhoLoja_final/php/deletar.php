<?php

    $selecionado = $_POST['selecionado'];

    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    mysqli_query($conexao, "DELETE FROM carrinho WHERE id_produto = (SELECT id FROM produtos WHERE nome = '$selecionado')");

    $query = "DELETE FROM produtos WHERE nome='$selecionado'";

    mysqli_query($conexao, $query);

    $id = mysqli_insert_id($query);

    unlink('../img/'.$id.'.png' );

?>