<?php
    session_start();
    $conexao = mysqli_connect("localhost:3306", "root", "C0x1nh4123", "vinho_loja");

    $resultado = mysqli_query($conexao, "
    SELECT * FROM carrinho 
    JOIN produtos ON produtos.id = carrinho.id_produto
    WHERE carrinho.id_usuario = {$_SESSION['id']}
    ");

    $produtos_finais = array();

    while ($ler = mysqli_fetch_assoc($resultado)){
        array_push($produtos_finais, $ler);
    };

    $json = json_encode($produtos_finais);

    echo $json;

?>